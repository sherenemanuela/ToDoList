package com.example.todolist;


    import android.content.Context;
    import android.content.Intent;
    import android.os.Bundle;

    import androidx.fragment.app.Fragment;
    import androidx.recyclerview.widget.LinearLayoutManager;
    import androidx.recyclerview.widget.RecyclerView;

    import android.view.LayoutInflater;
    import android.view.View;
    import android.view.ViewGroup;
    import android.widget.Toast;

    import com.google.android.material.checkbox.MaterialCheckBox;
    import com.google.android.material.floatingactionbutton.FloatingActionButton;

    import java.io.BufferedReader;
    import java.io.FileInputStream;
    import java.io.FileNotFoundException;
    import java.io.FileOutputStream;
    import java.io.IOException;
    import java.io.InputStreamReader;
    import java.io.OutputStreamWriter;
    import java.util.ArrayList;

public class FragmentCompleted extends Fragment implements CompletedRecyclerViewAdapter.ItemClickListener{
    FloatingActionButton insert;

    private final static String FILE_NAME = "todolist.txt";
    ArrayList<String> data = new ArrayList<>();
    CompletedRecyclerViewAdapter adapter;

    MaterialCheckBox checkBox;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_completed, container, false);
        // button insert - start
        insert = v.findViewById(R.id.insert);
        insert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getActivity(),InsertActivity.class));
            }
        });
        // button insert - end

        // recycle view
        insertToAL(v);
        RecyclerView recyclerView = v.findViewById(R.id.rvCompleted);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        adapter = new CompletedRecyclerViewAdapter(getContext(), data);
        adapter.setClickListener(this);
        recyclerView.setAdapter(adapter);
        // end

        return v;
    }
    public void insertToAL(View v){

        FileInputStream fis = null;

        try {
            fis = getActivity().openFileInput(FILE_NAME);
            InputStreamReader isr = new InputStreamReader(fis);
            BufferedReader br = new BufferedReader(isr);
            String text;

            while((text = br.readLine()) != null){
                String str = text.toString();
                String title = str.substring(0, str.indexOf(";"));
                String date = str.substring(str.indexOf(";") + 1, str.lastIndexOf(";"));
                if(str.substring(str.lastIndexOf(";") + 1, str.length()).equals("completed")){
                    data.add(title + " | " + date);
                }
            }

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if(fis != null){
                try {
                    fis.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

    }

    @Override
    public void onItemClick(View view, int position) {
        String title = adapter.getItem(position).substring(0, adapter.getItem(position).indexOf("|") - 1);
        update(title);
        Toast.makeText(getContext(), title + " ongoing!", Toast.LENGTH_SHORT).show();
        // app service
        getActivity().startService(new Intent(getActivity(), NewService.class));
        // app service - end
        startActivity(new Intent(getActivity(), MainActivity.class));
    }

    public void update(String oldTitle){
        copyFile();
        updateFile(oldTitle);
    }

    public void copyFile(){
        cleanFile("temp.txt");
        FileInputStream fis = null;
        try {
            fis = getActivity().openFileInput(FILE_NAME);
            InputStreamReader isr = new InputStreamReader(fis);
            BufferedReader br = new BufferedReader(isr);
            String text;

            while((text = br.readLine()) != null){
                writeFile(text.toString() + "\n", "temp.txt");
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if(fis != null){
                try {
                    fis.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    public void updateFile(String oldTitle){
        cleanFile(FILE_NAME);
        FileInputStream fis = null;
        try {
            fis = getActivity().openFileInput("temp.txt");
            InputStreamReader isr = new InputStreamReader(fis);
            BufferedReader br = new BufferedReader(isr);
            String text;

            while((text = br.readLine()) != null){
                String str = text.toString();
                if(str.substring(0, str.indexOf(";")).equals(oldTitle)){
                    String newText = str.substring(0,str.lastIndexOf(";")+1) + "ongoing\n";
                    writeFile(newText, FILE_NAME);
                } else {
                    writeFile(str + "\n", FILE_NAME);
                }

            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if(fis != null){
                try {
                    fis.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    public void writeFile(String content, String filename){
        FileOutputStream fOut = null;
        try {
            fOut = getActivity().openFileOutput(filename, Context.MODE_APPEND);
            OutputStreamWriter osw = new OutputStreamWriter(fOut);
            osw.write(content);
            osw.flush();
            osw.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void cleanFile(String filename){
        FileOutputStream fOut = null;
        try {
            fOut = getActivity().openFileOutput(filename, Context.MODE_PRIVATE);
            OutputStreamWriter osw = new OutputStreamWriter(fOut);
            osw.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}